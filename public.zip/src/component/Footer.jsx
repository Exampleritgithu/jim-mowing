import React from "react";

const Footer = () => {
  return (
    <div className="border-t-1 mx-36 my-20 mt-20 ">
      <div className="flex  mr-11 mt-6 ">
        <p className="hover:cursor-pointer">© 2024 Edusity. All rights reserved</p>
        <div className=" hover:cursor-pointer ml-auto flex">
          <p>Terms of services</p>
          <p className="ml-6"> Privacy polices</p>
        </div>
      </div>
    </div>
  );
};

export default Footer;
