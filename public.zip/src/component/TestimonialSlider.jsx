import React from 'react'

const TestimonialSlider = () => {
  return (
    <div className='flex justify-center items-center flex-col mt-14'>
      <h3 className='font-bold text-blue-700 tracking-wider'>TESTIMONIALS</h3>
      <p className='text-4xl font-bold mt-2'>What Student Says</p>
    </div>
  )
}

export default TestimonialSlider
