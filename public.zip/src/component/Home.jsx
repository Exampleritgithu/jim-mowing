import React from 'react';

const Home = () => {
  return (
    <div className="relative bg-[url('/herobg.jpg')] bg-cover h-screen flex flex-col justify-center items-center">
      {/* Overlay */}
      <div className="absolute inset-0 bg-blue-950 opacity-50 z-0"></div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-4">
        <h1 className="text-7xl font-bold max-w-5xl text-white mx-auto">We Ensure better education for a better world</h1>
        <p className="text-white max-w-2xl my-4">
          Our cutting-edge curriculum is designed to empower students with the knowledge, skills, and experiences needed to excel in the dynamic field of education
        </p>
        <button className="bg-white flex items-center justify-center rounded-4xl px-9 p-4 my-2">
          Explore more
          <img src="arrow.png" alt="" className="h-5 w-5 mx-2" />
        </button>
      </div>
    </div>
  );
};

export default Home;
