import React, { useEffect, useState } from 'react';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50); 
    };

    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-[#212EA0] shadow-md' : 'bg-transparent'
      } p-2 flex justify-between items-center`}
    >
      <img src="/Logo.png" alt="Logo" className="w-52 h-10 mx-32" />
      
      <div className="flex justify-center items-center">
        <p className="text-white text-1xl p-4 hover:cursor-pointer">Home</p>
        <p className="text-white text-1xl p-4 hover:cursor-pointer">Program</p>
        <p className="text-white text-1xl p-4 hover:cursor-pointer">About us</p>
        <p className="text-white text-1xl p-4 hover:cursor-pointer">Campus</p>
        <p className="text-white text-1xl p-4 hover:cursor-pointer">Testimonials</p>
      </div>

      <button className="bg-white rounded-4xl p-3 px-8 mx-36 font-bold hover:cursor-pointer">
        Contact us
      </button>
    </div>
  );
};

export default Navbar;
