import React from "react";
import { FaReact } from "react-icons/fa"; // Import React icon

const Program = () => {
  const programs = [
    { img: "Add1.jpg", title: "BSCS" },
    { img: "Add2.jpg", title: "PHD" },
    { img: "Add3.jpg", title: "Post Graduation" },
  ];

  return (
    <div className="flex flex-col justify-between items-center my-6">
      <p className="text-blue-800 font-bold uppercase">Our PROGRAM</p>
      <h2 className="text-4xl font-bold my-4">What We Offer</h2>

      <div className="flex justify-center gap-6 mt-16">
        {programs.map((program, index) => (
          <div
            key={index}
            className="relative cursor-pointer w-72 h-80 rounded-2xl overflow-hidden group"
          >
            <img
              src={program.img}
              alt=""
              className="w-full h-full object-cover rounded-2xl"
            />

            {/* Overlay */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              {/* Background overlay */}
              <div className="absolute inset-0 bg-blue-800 opacity-0 group-hover:opacity-30 transition-opacity duration-300 pointer-events-none"></div>

              {/* React Icon (on hover) */}
              <FaReact
                className="text-white text-5xl mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 relative z-10"
              />

              {/* Program Title (on hover) */}
              <p className="text-white font-bold opacity-0 group-hover:opacity-100 transition-opacity duration-300 relative z-10">
                {program.title}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Program;
