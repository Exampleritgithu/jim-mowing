import React from "react";

const Contactus = () => {
  return (
    <div className=" mt-32">
    <div className="flex flex-col justify-center">
      <div className="  flex justify-center items-center flex-col mt-36">
        <p className="uppercase font-bold text-blue-800 tracking-wider">
          {"Contact Us "}
        </p>
        <p className="text-4xl font-bold  "> Get in Touch</p>
      </div>
      <div className="mt-12 flex mx-44 ">
        <p className=" text-3xl ">Send us a message</p>
        <img src="msg.png" alt="" className="w-10 mx-2 h-8" />
      </div>
      <div className="mt-4 mx-44 w-[30%] h-auto">
        <p className="text-slate-500">
          Feel free to reach out through contact form or find our contact
          information below. Your feedback, questions, and suggestions are
          important to us as we strive to provide exceptional service to our
          university community.
          <div className="flex  mt-10">
            <img src="Email.png" alt="" className="w-8 h-6 mr-4 " />
            <p className="text-slate-500"> WebNest786@gmail.com</p>
          </div>
          <div className="flex  mt-7">
            <img src="Phone.png" alt="" className="w-6 h-6 mr-4" />
            <p className="text-slate-500"> +92307-1515315</p>
          </div>
          <div className="flex  mt-7">
            <img src="location.png" alt="" className="w-6 h-6 mr-4" />
            <p className="text-slate-500"> Islamabad ,soan garden</p>
          </div>
        </p>
      </div>
      
    </div>
    <div className="">
        <form>
          <label>Your name</label>
        
          <button className="bg-blue-800 text-white flex items-center justify-center rounded-4xl px-9 p-4 my-2">
          Explore more
          <img src="icon.png" alt="" className="h-5 w-5 mx-2" />
        </button>
        </form>
      </div>
    </div>
  );
};

export default Contactus;
