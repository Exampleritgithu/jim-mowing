import React from "react";

const About = () => {
  return (
    <div className="flex mt-36">
      {/* Video Section */}
      <div className="w-full  px-28 h-100% ">
        <video width="600" controls>
          <source src="/collage.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div>
        {/* Text Section */}
        <h1 className="text-blue-800 font-bold tracking-wider">ABOUT UNIVERSITY</h1>
        <p className="text-4xl font-bold my-4">Nurturing Tomorrow's</p>
        <p className=" text-4xl font-bold">Leaders Today</p>
        <div className="w-[70%] h-auto">
        <p className="mt-5">
          Embark on a transformative educational journey with our university's
          comprehensive education programs. Our cutting-edge curriculum is
          designed to empower students with the knowledge, skills, and
          experiences needed to excel in the dynamic field of education.
        </p>
        <p className="mt-5"> With a focus on innovation, hands-on learning, and personalized mentorship,
          our programs prepare aspiring educators to make a meaningful impact in
          classrooms, schools, and communities</p>
          <p className="mt-5">Whether you aspire to become a
          teacher, administrator, counselor, or educational leader, our diverse
          range of programs offers the perfect pathway to achieve your goals and
          unlock your full potential in shaping the future of education</p>
          </div>
      </div>
      
    </div>
  );
};

export default About;
