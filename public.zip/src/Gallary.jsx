import React from 'react'

const Gallary = () => {
  return (
    <div className='flex flex-col justify-center items-center mt-24'>                      
      <p className='uppercase text-blue-800  font-bold tracking-wider'>Gallery</p>
      <p className='text-2xl font-bold mt-4 '> CAMPUS PHOTOS</p>
      <div className='flex mt-24 '>
      <img src="gallery1.png" alt="" className=" w-60 h-80 rounded-2xl mx-4" />
      <img src="gallery2.png" alt="" className=" w-60 h-80 rounded-2xl mx-4" />
      <img src="gallery3.png" alt="" className=" w-60 h-80 rounded-2xl mx-4" />
      <img src="gallery4.png" alt="" className=" w-60 h-80 rounded-2xl mx-4" />
      </div>
      <div className='mt-8'>
      <button className="bg-blue-800 text-white flex items-center justify-center rounded-4xl px-9 p-4 my-2">
          See more here
          <img src="icon.png" alt="" className="h-3 w-5 mx-2" />
        </button>
      </div>
    </div>
  )
}

export default Gallary
